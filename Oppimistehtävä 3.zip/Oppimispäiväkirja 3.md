
# Oppimispäiväkirja 3

## Olivatko oppimistavoitteet selvät?

Olivat, tehtävänanto oli tosi selkeä.

## Oliko oppimateriaalista hyötyä tehtävien tekemisessä?

Oli, Oppimateriaalin kanssa sain tehtävän tehtyä vaikka yksi tunti jäi väliin

## Oliko tehtävistä hyötyä oppimisen kannalta?

Oli. Opin PHP:n ja tietokannan yhteistoimintaa.

## Mikä oli helppoa, mikä vaikeaa?  Miksi?

Tietokantalauseet olivat helppoja, vaikeinta ehkä pohtiminen kuinka tietokantahakujen tulos tallennetaan ja näytetään sivulla.
Lisäksi haasteita toi Jsonin avulla tehty haku, jossa haettiin jotain muuta kun kaikkia tietoja.

## Miten hyvin saavutit oppimistavoitteet?

Hyvin, opin kaiken mitä piti (en tosin pahemmin mitään ylimääräistä)

## Paljonko aikaa kului tehtävien tekemiseen?

Tunnilla käytetyn ajan lisäksi n. 5h.